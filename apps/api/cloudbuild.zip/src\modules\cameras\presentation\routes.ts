import { Router, Request, Response } from 'express';
import Camera from '../../../infrastructure/database/models/Camera';
import { requireAuth, requireRole } from '../../../shared/middlewares/auth';
import { getSocket, emitToOperators } from '../../../shared/utils/socket';

const router = Router();

// CREAR CÁMARA
// POST /api/cameras
router.post('/', requireAuth, requireRole(['admin', 'supervisor']), async (req: Request, res: Response) => {
  try {
    const { name, latitude, longitude, address, streamUrl, coverageRadius, isPublic, authorityId } = req.body;

    if (!name || !latitude || !longitude || !address || !streamUrl || !authorityId) {
      return res.status(400).json({
        success: false,
        message: 'Faltan datos obligatorios',
      });
    }

    const camera = await Camera.create({
      name,
      location: {
        type: 'Point',
        coordinates: [longitude, latitude],
        address,
      },
      streamUrl,
      status: 'online',
      coverageRadius: coverageRadius || 100,
      isPublic: isPublic || false,
      authorityId,
    });

    const cameraData = {
      id: camera._id,
      name: camera.name,
      location: {
        latitude: camera.location.coordinates[1],
        longitude: camera.location.coordinates[0],
        address: camera.location.address,
      },
      streamUrl: camera.streamUrl,
      status: camera.status,
      coverageRadius: camera.coverageRadius,
      isPublic: camera.isPublic,
    };

    try {
      getSocket().emit('camera:new', cameraData);
      emitToOperators('camera:new', cameraData);
    } catch (wsError) {
      console.error('Error emitiendo WebSocket (camera:new):', wsError);
    }

    res.status(201).json({
      success: true,
      message: 'Cámara creada exitosamente',
      data: { camera: cameraData },
    });

  } catch (error: any) {
    console.error('Error creando cámara:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message,
    });
  }
});

// OBTENER TODAS LAS CÁMARAS
// GET /api/cameras
router.get('/', async (req: Request, res: Response) => {
  try {
    const cameras = await Camera.find().sort({ createdAt: -1 });

    res.json({
      success: true,
      count: cameras.length,
      data: cameras.map(camera => ({
        id: camera._id,
        name: camera.name,
        location: {
          latitude: camera.location.coordinates[1],
          longitude: camera.location.coordinates[0],
          address: camera.location.address,
        },
        streamUrl: camera.streamUrl,
        status: camera.status,
        coverageRadius: camera.coverageRadius,
        isPublic: camera.isPublic,
      })),
    });

  } catch (error: any) {
    console.error('Error obteniendo cámaras:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
    });
  }
});

// ACTUALIZAR CÁMARA
// PUT /api/cameras/:id
router.put('/:id', requireAuth, requireRole(['admin', 'supervisor']), async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    const camera = await Camera.findByIdAndUpdate(
      id,
      updateData,
      { new: true }
    );

    if (!camera) {
      return res.status(404).json({
        success: false,
        message: 'Cámara no encontrada',
      });
    }

    const cameraData = {
      id: camera._id,
      name: camera.name,
      location: {
        latitude: camera.location.coordinates[1],
        longitude: camera.location.coordinates[0],
        address: camera.location.address,
      },
      streamUrl: camera.streamUrl,
      status: camera.status,
      coverageRadius: camera.coverageRadius,
      isPublic: camera.isPublic,
    };

    try {
      getSocket().emit('camera:updated', cameraData);
      emitToOperators('camera:updated', cameraData);
    } catch (wsError) {
      console.error('Error emitiendo WebSocket (camera:updated):', wsError);
    }

    res.json({
      success: true,
      message: 'Cámara actualizada',
      data: { camera: cameraData },
    });

  } catch (error: any) {
    console.error('Error actualizando cámara:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
    });
  }
});

// ELIMINAR CÁMARA
// DELETE /api/cameras/:id
router.delete('/:id', requireAuth, requireRole(['admin', 'supervisor']), async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const camera = await Camera.findByIdAndDelete(id);

    if (!camera) {
      return res.status(404).json({ success: false, message: 'Cámara no encontrada' });
    }

    try {
      getSocket().emit('camera:deleted', { id });
      emitToOperators('camera:deleted', { id });
    } catch (wsError) {
      console.error('Error emitiendo WebSocket (camera:deleted):', wsError);
    }

    res.json({ success: true, message: 'Cámara eliminada exitosamente' });
  } catch (error: any) {
    console.error('Error eliminando cámara:', error.message);
    res.status(500).json({ success: false, message: 'Error interno del servidor', error: error.message });
  }
});

export { router as cameraRouter };